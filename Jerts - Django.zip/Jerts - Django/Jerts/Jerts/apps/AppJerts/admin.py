from django.contrib import admin
from Jerts.apps.AppJerts.models import *
# Register your models here.

admin.site.register(Contacto)