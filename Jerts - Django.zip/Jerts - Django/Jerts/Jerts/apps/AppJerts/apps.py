from django.apps import AppConfig


class AppjertsConfig(AppConfig):
    name = 'AppJerts'
